package com.example.proxy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcaradoenejinekissApplication {

	public static void main(String[] args) {
		SpringApplication.run(AcaradoenejinekissApplication.class, args);
	}

}
